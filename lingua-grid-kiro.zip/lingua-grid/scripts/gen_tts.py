"""Generate hint MP3s for every phrase in data/phrases.json using edge-tts.
Runs in GitHub Actions (no local install needed). Output: audio/{id}.mp3"""
import asyncio, json, os
import edge_tts

async def main():
    data = json.load(open("data/phrases.json", encoding="utf-8"))
    os.makedirs("audio", exist_ok=True)
    for p in data["phrases"]:
        out = f"audio/{p['id']}.mp3"
        if os.path.exists(out):
            continue
        voice = data["voices"][p["lang"]]
        try:
            await edge_tts.Communicate(p["text"], voice, rate="-10%").save(out)
            print("ok ", p["id"], voice)
        except Exception as e:
            print("FAIL", p["id"], voice, e)

asyncio.run(main())
