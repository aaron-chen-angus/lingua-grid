# Product Steering — LINGUA//GRID

A TRON-style multilingual pronunciation runner for desktop browsers. The player rides a neon light-cycle down a grid highway. Ten barriers rise, each showing a phrase in one language (flag, native script, romanisation, IPA). Speaking it acceptably drops the barrier. Lowest final time wins.

Audience: public/students at school events (Republic Polytechnic, Singapore). Must feel like a TikTok-style mini-game: instant, loud, juicy, forgiving.

Design pillars:
1. Fun first — lenient pass threshold, big feedback, combo/perfect callouts.
2. Never stuck — retry, hint (+5s), skip after repeated failure (+15s).
3. Honest data — every attempt's transcript and similarity is stored.
4. Zero setup — open URL, allow mic, play.
