# Tech Steering — LINGUA//GRID

## Hard constraints
- Vanilla HTML/CSS/JS. Single `index.html` (inline CSS + JS). No npm, no bundler, no build step. The author cannot install software locally.
- Hosted on GitHub Pages (HTTPS — required for microphone access).
- Target browsers: Chrome and Edge desktop (latest). Any other browser shows an "Unsupported browser" screen.
- Allowed runtime externals (CDN, pinned versions only): Google Fonts (Orbitron, Noto Sans families), `pinyin-pro` (Mandarin tone-insensitive matching). Everything else is written by hand.
- No emoji flags (they render as letters on Windows). Flags are inline SVG.
- No image/audio assets required to run. Optional pre-generated hint MP3s in `/audio/{phraseId}.mp3`.

## Browser APIs
- `webkitSpeechRecognition` / `SpeechRecognition` for speech-to-text (cloud-backed in Chrome; needs internet).
- `navigator.mediaDevices.getUserMedia` + Web Audio `AnalyserNode` for mic level / waveform.
- `speechSynthesis` for hint playback fallback.
- Canvas 2D for the highway renderer (pseudo-3D, glow via `shadowBlur` + additive compositing).
- Web Audio oscillators for all SFX (synthesised, no files).
- `localStorage` for runs/leaderboard; optional `fetch` POST to a configurable webhook.

## Code conventions
- One global `CONFIG` object at top of script holds every tunable (thresholds, penalties, pool, webhook URL, flag mapping).
- Logical modules as plain objects/IIFEs in one file: `Config, Phrases, Store, Audio, Speech, Scorer, Renderer, UI, Game`.
- Scoring logic must be pure functions, testable from `tests.html` (a separate file that loads `index.html` logic via copy of the Scorer module or a shared `scorer.js` — see design.md).
- All user-facing text in English.
