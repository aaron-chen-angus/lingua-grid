# Using this pack in Kiro
1. Create an empty repo/folder, copy everything here into it (keep `.kiro/` and `.github/`).
2. Open the folder in Kiro. Steering files load automatically.
3. Open `.kiro/specs/lingua-grid/tasks.md` → run tasks 1–15 in order ("Start task").
4. Push to GitHub, enable Pages. Then Actions → "Generate hint audio" → Run workflow (creates `/audio/*.mp3`).
5. Open the Pages URL in Chrome or Edge, allow the mic.
Tune difficulty in `CONFIG.threshold`. Add phrases in `data/phrases.json`, then re-inline into `index.html` and re-run the audio workflow.
